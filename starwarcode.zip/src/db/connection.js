const mongoose = require("mongoose");

mongoose.connect("mongodb://locaohost:27017/registration", {
  useNewUrlParser: true,
  useUnifiesTopology: true,
  useCreateIndex: true
}).then(() => {
  console.log("connection successful");
}).catch((e) => {
  console.log("no connection due to ${e}");
})
