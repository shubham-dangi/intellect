const express = require ("express");
const path = require("path");
const hbs = require("hbs");
const bcrypt = require("bcryptjs");
// const cookies = require("cookies");
const app = express();
const port = process.env.PORT || 5555 ;
const Registration = require("./models/registration");
const auth = require("./middleware/auth");
const {json} = require ("express");

require("./db/connection");

const static_path = path.join(__dirname, "../public");
const templates_path = path.join(__dirname, "../templates/views");
const partials_path = path.join(__dirname, "../templates/partials");

app.use(express.json());
// app.use(express.cookies());
app.use(express.urlencoded({extended: false}));
app.use(express.static(static_path));

app.set("view engine", "hbs");
app.set("views", templates_path);
hbs.registerPartials(partials_path);

app.get('/', (req, res) => {
    res.render("index")
});

app.get('/secret', auth, (req, res) => {
    res.render("secret")
});

app.get('/logout', auth, async (req, res) => {
    try{
      // res.clearCookie("jwt");
      console.log("Logout successful");

      await req.user.save();
      res.render("login");

    }catch(error){
      res.status(500).send(error);
    }
});

app.get('/registration', (req, res) => {
    res.render('registration')
})

app.post('/registration', async(req, res) => {
    try{
      const registerPerson = new Register ({
        username: req.body.username,
        password: req.body.password,
        name: req.body.name,
        role: req.body.role
      })

      const token = await registerPerson.generateAuthToken();

      res.cookie("jwt", token, {
        expires: new Date(Date.now() + 500000),
        httpOnly: true
      });
      const registered = await registerPerson.save();
      res.status(201).render("index");
    } catch(error){
        res.status(401).send(error);
    }
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.post('/login', async(req, res) => {
  try{
    const username = req.body.username;
    const password = req.body.password;
    const personUserName = await Register.findOne({username:username});

    const isMatch = await bcrypt.compare(password, personUserName.password);
    const token = await personUserName.generateAuthToken();

    // res.cookie("jwt", token, {
    //   expires: new Date(Date.now() + 500000),
    //   httpOnly: true
    // });

    if (isMatch){
      res.status(201).render("index");
    }else {
      res.send("invalid login detail");
    }

    // res.status(201).render("index");
  } catch(error){
      res.status(400).send(error);
  }
})

app.listen(port, () =>
{
    console.log("server is running on port number " + port);
})
