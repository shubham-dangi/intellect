const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const registrationSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true,
    unique: true
  },
  role: {
    type: String,
    required: true
  },
  tokens: [{
    token: {
      type: String,
      required: true
    }
  }]
  })

// generating JWT Token

  registrationSchema.methods.generateAuthToken = async function () {
    try{
      const token = jwt.sign({_id: this._id.toString()}, process.env.SECRET-KEY);
      this.tokens = this.tokens.concat({token:token});
      await this.save();
      return token;
    }catch(error){
      res.send(error);
    }
  }

  //password hashing

  registrationSchema.pre("save", async function (next) {
    if(this.isModified("password")){
      // const passwordHash = await bcrypt.hash(password, 10);
      console.log("the current password is " + this.password);
      this.password = await bcrypt.hash(this.password, 10);
      console.log("the current password is " + this.password);
    }

     next();
  })


const Registration = new mongoose.model ("Registration", registrationSchema);

module.exports = Registration;
